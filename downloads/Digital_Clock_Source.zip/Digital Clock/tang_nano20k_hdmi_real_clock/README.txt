Tang Nano 20K - HDMI 24-hour Digital Clock
==========================================

This version behaves as a CLOCK, not a stopwatch.
Display format: HH:MM:SS, 24-hour rollover (23:59:59 -> 00:00:00).

TIME SETTING
------------
S1 (pin 87): add 1 hour
S2 (pin 88): add 1 minute and reset seconds to 00

Power-up fallback is set to 15:41:00 in src/video_top.v.
Change INIT_HOUR / INIT_MINUTE / INIT_SECOND if desired.

IMPORTANT
---------
An FPGA by itself does not know the actual civil time and has no battery-backed
clock. After power is removed, this design restarts from INIT_* and must be set
again with S1/S2. If time must survive power-off and stay accurate, add an RTC
module such as DS3231.

BUILD
-----
1. Open real_clock_hdmi.gprj in Gowin EDA.
2. Set top module to video_top.
3. Run Synthesize.
4. Run Place & Route.
5. Program the generated .fs file.
