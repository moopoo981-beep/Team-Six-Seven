// Colorful 1280x720 HDMI digital clock screen.
module clock_screen (
    input              I_pxl_clk,
    input              I_rst_n,
    input      [3:0]   I_hour_tens,
    input      [3:0]   I_hour_ones,
    input      [3:0]   I_min_tens,
    input      [3:0]   I_min_ones,
    input      [3:0]   I_sec_tens,
    input      [3:0]   I_sec_ones,
    input              I_blink,

    input      [11:0]  I_h_total,
    input      [11:0]  I_h_sync,
    input      [11:0]  I_h_bporch,
    input      [11:0]  I_h_res,
    input      [11:0]  I_v_total,
    input      [11:0]  I_v_sync,
    input      [11:0]  I_v_bporch,
    input      [11:0]  I_v_res,
    input              I_hs_pol,
    input              I_vs_pol,

    output             O_de,
    output reg         O_hs,
    output reg         O_vs,
    output     [7:0]   O_data_r,
    output     [7:0]   O_data_g,
    output     [7:0]   O_data_b
);

reg [11:0] H_cnt;
reg [11:0] V_cnt;
wire Pout_de_w;
wire Pout_hs_w;
wire Pout_vs_w;
reg [4:0] Pout_de_dn;
reg [4:0] Pout_hs_dn;
reg [4:0] Pout_vs_dn;

always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n)
        H_cnt <= 12'd0;
    else if (H_cnt >= I_h_total - 1'b1)
        H_cnt <= 12'd0;
    else
        H_cnt <= H_cnt + 1'b1;
end

always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n)
        V_cnt <= 12'd0;
    else if ((H_cnt >= I_h_total - 1'b1) && (V_cnt >= I_v_total - 1'b1))
        V_cnt <= 12'd0;
    else if (H_cnt >= I_h_total - 1'b1)
        V_cnt <= V_cnt + 1'b1;
end

assign Pout_de_w =
       (H_cnt >= I_h_sync + I_h_bporch) &&
       (H_cnt <  I_h_sync + I_h_bporch + I_h_res) &&
       (V_cnt >= I_v_sync + I_v_bporch) &&
       (V_cnt <  I_v_sync + I_v_bporch + I_v_res);

assign Pout_hs_w = ~((H_cnt >= 12'd0) && (H_cnt < I_h_sync));
assign Pout_vs_w = ~((V_cnt >= 12'd0) && (V_cnt < I_v_sync));

always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        Pout_de_dn <= 5'b00000;
        Pout_hs_dn <= 5'b11111;
        Pout_vs_dn <= 5'b11111;
    end else begin
        Pout_de_dn <= {Pout_de_dn[3:0], Pout_de_w};
        Pout_hs_dn <= {Pout_hs_dn[3:0], Pout_hs_w};
        Pout_vs_dn <= {Pout_vs_dn[3:0], Pout_vs_w};
    end
end

assign O_de = Pout_de_dn[4];

always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        O_hs <= 1'b1;
        O_vs <= 1'b1;
    end else begin
        O_hs <= I_hs_pol ? ~Pout_hs_dn[3] : Pout_hs_dn[3];
        O_vs <= I_vs_pol ? ~Pout_vs_dn[3] : Pout_vs_dn[3];
    end
end

wire De_pos = ~Pout_de_dn[1] & Pout_de_dn[0];
wire De_neg =  Pout_de_dn[1] & ~Pout_de_dn[0];
wire Vs_pos = ~Pout_vs_dn[1] & Pout_vs_dn[0];
reg [11:0] De_hcnt;
reg [11:0] De_vcnt;

always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n)
        De_hcnt <= 12'd0;
    else if (De_pos)
        De_hcnt <= 12'd0;
    else if (Pout_de_dn[1])
        De_hcnt <= De_hcnt + 1'b1;
end

always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n)
        De_vcnt <= 12'd0;
    else if (Vs_pos)
        De_vcnt <= 12'd0;
    else if (De_neg)
        De_vcnt <= De_vcnt + 1'b1;
end

// 7x9 digit font
function [6:0] digit_font;
    input [3:0] digit;
    input [3:0] row;
    begin
        case (digit)
            4'd0: case(row)
                0:digit_font=7'b0111110;1:digit_font=7'b1100011;2:digit_font=7'b1100011;
                3:digit_font=7'b1100011;4:digit_font=7'b1100011;5:digit_font=7'b1100011;
                6:digit_font=7'b1100011;7:digit_font=7'b1100011;8:digit_font=7'b0111110;
                default:digit_font=0;endcase
            4'd1: case(row)
                0:digit_font=7'b0001100;1:digit_font=7'b0011100;2:digit_font=7'b0111100;
                3:digit_font=7'b0001100;4:digit_font=7'b0001100;5:digit_font=7'b0001100;
                6:digit_font=7'b0001100;7:digit_font=7'b0001100;8:digit_font=7'b1111111;
                default:digit_font=0;endcase
            4'd2: case(row)
                0:digit_font=7'b0111110;1:digit_font=7'b1100011;2:digit_font=7'b0000011;
                3:digit_font=7'b0000110;4:digit_font=7'b0011100;5:digit_font=7'b0110000;
                6:digit_font=7'b1100000;7:digit_font=7'b1100000;8:digit_font=7'b1111111;
                default:digit_font=0;endcase
            4'd3: case(row)
                0:digit_font=7'b0111110;1:digit_font=7'b1100011;2:digit_font=7'b0000011;
                3:digit_font=7'b0011110;4:digit_font=7'b0000011;5:digit_font=7'b0000011;
                6:digit_font=7'b0000011;7:digit_font=7'b1100011;8:digit_font=7'b0111110;
                default:digit_font=0;endcase
            4'd4: case(row)
                0:digit_font=7'b0000110;1:digit_font=7'b0001110;2:digit_font=7'b0011110;
                3:digit_font=7'b0110110;4:digit_font=7'b1100110;5:digit_font=7'b1111111;
                6:digit_font=7'b0000110;7:digit_font=7'b0000110;8:digit_font=7'b0000110;
                default:digit_font=0;endcase
            4'd5: case(row)
                0:digit_font=7'b1111111;1:digit_font=7'b1100000;2:digit_font=7'b1100000;
                3:digit_font=7'b1111110;4:digit_font=7'b0000011;5:digit_font=7'b0000011;
                6:digit_font=7'b0000011;7:digit_font=7'b1100011;8:digit_font=7'b0111110;
                default:digit_font=0;endcase
            4'd6: case(row)
                0:digit_font=7'b0011110;1:digit_font=7'b0110000;2:digit_font=7'b1100000;
                3:digit_font=7'b1111110;4:digit_font=7'b1100011;5:digit_font=7'b1100011;
                6:digit_font=7'b1100011;7:digit_font=7'b1100011;8:digit_font=7'b0111110;
                default:digit_font=0;endcase
            4'd7: case(row)
                0:digit_font=7'b1111111;1:digit_font=7'b0000011;2:digit_font=7'b0000110;
                3:digit_font=7'b0001100;4:digit_font=7'b0011000;5:digit_font=7'b0011000;
                6:digit_font=7'b0011000;7:digit_font=7'b0011000;8:digit_font=7'b0011000;
                default:digit_font=0;endcase
            4'd8: case(row)
                0:digit_font=7'b0111110;1:digit_font=7'b1100011;2:digit_font=7'b1100011;
                3:digit_font=7'b0111110;4:digit_font=7'b1100011;5:digit_font=7'b1100011;
                6:digit_font=7'b1100011;7:digit_font=7'b1100011;8:digit_font=7'b0111110;
                default:digit_font=0;endcase
            4'd9: case(row)
                0:digit_font=7'b0111110;1:digit_font=7'b1100011;2:digit_font=7'b1100011;
                3:digit_font=7'b1100011;4:digit_font=7'b0111111;5:digit_font=7'b0000011;
                6:digit_font=7'b0000011;7:digit_font=7'b0000110;8:digit_font=7'b0111100;
                default:digit_font=0;endcase
            default: digit_font=7'b0000000;
        endcase
    end
endfunction

// Small 5x7 font used by DIGITAL CLOCK and 24 HOUR.
function [4:0] font5;
    input [7:0] ch;
    input [2:0] row;
    begin
        font5 = 5'b00000;
        case(ch)
            8'h41: case(row) // A
                0:font5=5'b01110;1:font5=5'b10001;2:font5=5'b10001;3:font5=5'b11111;
                4:font5=5'b10001;5:font5=5'b10001;6:font5=5'b10001;default:font5=0;endcase
            8'h43: case(row) // C
                0:font5=5'b01110;1:font5=5'b10001;2:font5=5'b10000;3:font5=5'b10000;
                4:font5=5'b10000;5:font5=5'b10001;6:font5=5'b01110;default:font5=0;endcase
            8'h44: case(row) // D
                0:font5=5'b11110;1:font5=5'b10001;2:font5=5'b10001;3:font5=5'b10001;
                4:font5=5'b10001;5:font5=5'b10001;6:font5=5'b11110;default:font5=0;endcase
            8'h47: case(row) // G
                0:font5=5'b01110;1:font5=5'b10001;2:font5=5'b10000;3:font5=5'b10111;
                4:font5=5'b10001;5:font5=5'b10001;6:font5=5'b01110;default:font5=0;endcase
            8'h48: case(row) // H
                0:font5=5'b10001;1:font5=5'b10001;2:font5=5'b10001;3:font5=5'b11111;
                4:font5=5'b10001;5:font5=5'b10001;6:font5=5'b10001;default:font5=0;endcase
            8'h49: case(row) // I
                0:font5=5'b11111;1:font5=5'b00100;2:font5=5'b00100;3:font5=5'b00100;
                4:font5=5'b00100;5:font5=5'b00100;6:font5=5'b11111;default:font5=0;endcase
            8'h4B: case(row) // K
                0:font5=5'b10001;1:font5=5'b10010;2:font5=5'b10100;3:font5=5'b11000;
                4:font5=5'b10100;5:font5=5'b10010;6:font5=5'b10001;default:font5=0;endcase
            8'h4C: case(row) // L
                0:font5=5'b10000;1:font5=5'b10000;2:font5=5'b10000;3:font5=5'b10000;
                4:font5=5'b10000;5:font5=5'b10000;6:font5=5'b11111;default:font5=0;endcase
            8'h4F: case(row) // O
                0:font5=5'b01110;1:font5=5'b10001;2:font5=5'b10001;3:font5=5'b10001;
                4:font5=5'b10001;5:font5=5'b10001;6:font5=5'b01110;default:font5=0;endcase
            8'h52: case(row) // R
                0:font5=5'b11110;1:font5=5'b10001;2:font5=5'b10001;3:font5=5'b11110;
                4:font5=5'b10100;5:font5=5'b10010;6:font5=5'b10001;default:font5=0;endcase
            8'h54: case(row) // T
                0:font5=5'b11111;1:font5=5'b00100;2:font5=5'b00100;3:font5=5'b00100;
                4:font5=5'b00100;5:font5=5'b00100;6:font5=5'b00100;default:font5=0;endcase
            8'h55: case(row) // U
                0:font5=5'b10001;1:font5=5'b10001;2:font5=5'b10001;3:font5=5'b10001;
                4:font5=5'b10001;5:font5=5'b10001;6:font5=5'b01110;default:font5=0;endcase
            8'h32: case(row) // 2
                0:font5=5'b01110;1:font5=5'b10001;2:font5=5'b00001;3:font5=5'b00010;
                4:font5=5'b00100;5:font5=5'b01000;6:font5=5'b11111;default:font5=0;endcase
            8'h34: case(row) // 4
                0:font5=5'b00010;1:font5=5'b00110;2:font5=5'b01010;3:font5=5'b10010;
                4:font5=5'b11111;5:font5=5'b00010;6:font5=5'b00010;default:font5=0;endcase
            default: font5=5'b00000;
        endcase
    end
endfunction

function [7:0] title_char;
    input [3:0] idx;
    begin
        case(idx)
            0:title_char=8'h44;  // D
            1:title_char=8'h49;  // I
            2:title_char=8'h47;  // G
            3:title_char=8'h49;  // I
            4:title_char=8'h54;  // T
            5:title_char=8'h41;  // A
            6:title_char=8'h4C;  // L
            7:title_char=8'h20;  // space
            8:title_char=8'h43;  // C
            9:title_char=8'h4C;  // L
           10:title_char=8'h4F;  // O
           11:title_char=8'h43;  // C
           12:title_char=8'h4B;  // K
            default:title_char=8'h20;
        endcase
    end
endfunction

function [7:0] footer_char;
    input [2:0] idx;
    begin
        case(idx)
            0:footer_char=8'h32; // 2
            1:footer_char=8'h34; // 4
            2:footer_char=8'h20;
            3:footer_char=8'h48; // H
            4:footer_char=8'h4F; // O
            5:footer_char=8'h55; // U
            6:footer_char=8'h52; // R
            default:footer_char=8'h20;
        endcase
    end
endfunction

// Large digits, 16x scale
localparam [11:0] DIGIT_W = 12'd112;
localparam [11:0] DIGIT_H = 12'd144;
localparam [11:0] Y_TIME  = 12'd300;
localparam [11:0] X_HT    = 12'd190;
localparam [11:0] X_HO    = 12'd320;
localparam [11:0] X_COL1  = 12'd455;
localparam [11:0] X_MT    = 12'd500;
localparam [11:0] X_MO    = 12'd630;
localparam [11:0] X_COL2  = 12'd765;
localparam [11:0] X_ST    = 12'd810;
localparam [11:0] X_SO    = 12'd940;

reg digit_pixel;
reg colon_pixel;
reg title_pixel;
reg footer_pixel;
reg [2:0] big_col;
reg [3:0] big_row;
reg [6:0] big_glyph;
reg [3:0] big_digit;
reg [11:0] big_x0;
reg [11:0] relx;
reg [11:0] rely;
reg [4:0] char_index;
reg [2:0] small_col;
reg [2:0] small_row;
reg [7:0] small_char;
reg [4:0] small_glyph;

always @(*) begin
    digit_pixel = 1'b0;
    colon_pixel = 1'b0;
    title_pixel = 1'b0;
    footer_pixel = 1'b0;
    big_col = 0;
    big_row = 0;
    big_glyph = 0;
    big_digit = 0;
    big_x0 = 0;
    relx = 0;
    rely = 0;
    char_index = 0;
    small_col = 0;
    small_row = 0;
    small_char = 8'h20;
    small_glyph = 0;

    if ((De_vcnt >= Y_TIME) && (De_vcnt < Y_TIME + DIGIT_H)) begin
        if ((De_hcnt >= X_HT) && (De_hcnt < X_HT + DIGIT_W)) begin
            big_x0 = X_HT; big_digit = I_hour_tens;
        end else if ((De_hcnt >= X_HO) && (De_hcnt < X_HO + DIGIT_W)) begin
            big_x0 = X_HO; big_digit = I_hour_ones;
        end else if ((De_hcnt >= X_MT) && (De_hcnt < X_MT + DIGIT_W)) begin
            big_x0 = X_MT; big_digit = I_min_tens;
        end else if ((De_hcnt >= X_MO) && (De_hcnt < X_MO + DIGIT_W)) begin
            big_x0 = X_MO; big_digit = I_min_ones;
        end else if ((De_hcnt >= X_ST) && (De_hcnt < X_ST + DIGIT_W)) begin
            big_x0 = X_ST; big_digit = I_sec_tens;
        end else if ((De_hcnt >= X_SO) && (De_hcnt < X_SO + DIGIT_W)) begin
            big_x0 = X_SO; big_digit = I_sec_ones;
        end

        if (big_x0 != 0) begin
            big_col = (De_hcnt - big_x0) >> 4;
            big_row = (De_vcnt - Y_TIME) >> 4;
            big_glyph = digit_font(big_digit, big_row);
            if ((big_col < 7) && (big_row < 9))
                digit_pixel = big_glyph[6-big_col];
        end

        // Blinking colons
        if (I_blink &&
            (((De_hcnt >= X_COL1) && (De_hcnt < X_COL1 + 12'd18)) ||
             ((De_hcnt >= X_COL2) && (De_hcnt < X_COL2 + 12'd18))) &&
            (((De_vcnt >= Y_TIME + 12'd40) && (De_vcnt < Y_TIME + 12'd58)) ||
             ((De_vcnt >= Y_TIME + 12'd92) && (De_vcnt < Y_TIME + 12'd110))))
            colon_pixel = 1'b1;
    end

    // DIGITAL CLOCK, 13 chars x 32 px
    if ((De_hcnt >= 12'd432) && (De_hcnt < 12'd848) &&
        (De_vcnt >= 12'd76) && (De_vcnt < 12'd104)) begin
        relx = De_hcnt - 12'd432;
        rely = De_vcnt - 12'd76;
        char_index = relx >> 5;
        small_col = relx[4:2];
        small_row = rely[4:2];
        small_char = title_char(char_index[3:0]);
        small_glyph = font5(small_char, small_row);
        if ((small_col < 5) && (small_row < 7))
            title_pixel = small_glyph[4-small_col];
    end

    // 24 HOUR, 7 chars x 32 px
    if ((De_hcnt >= 12'd528) && (De_hcnt < 12'd752) &&
        (De_vcnt >= 12'd555) && (De_vcnt < 12'd583)) begin
        relx = De_hcnt - 12'd528;
        rely = De_vcnt - 12'd555;
        char_index = relx >> 5;
        small_col = relx[4:2];
        small_row = rely[4:2];
        small_char = footer_char(char_index[2:0]);
        small_glyph = font5(small_char, small_row);
        if ((small_col < 5) && (small_row < 7))
            footer_pixel = small_glyph[4-small_col];
    end
end

// Decorative UI
wire top_cyan   = (De_vcnt < 12'd12) && (De_hcnt < 12'd320);
wire top_green  = (De_vcnt < 12'd12) && (De_hcnt >= 12'd320) && (De_hcnt < 12'd640);
wire top_yellow = (De_vcnt < 12'd12) && (De_hcnt >= 12'd640) && (De_hcnt < 12'd960);
wire top_pink   = (De_vcnt < 12'd12) && (De_hcnt >= 12'd960);

wire main_panel = (De_hcnt >= 12'd110) && (De_hcnt < 12'd1170) &&
                  (De_vcnt >= 12'd160) && (De_vcnt < 12'd525);
wire main_border = main_panel &&
                  ((De_hcnt < 12'd118) || (De_hcnt >= 12'd1162) ||
                   (De_vcnt < 12'd168) || (De_vcnt >= 12'd517));

wire time_panel = (De_hcnt >= 12'd150) && (De_hcnt < 12'd1130) &&
                  (De_vcnt >= 12'd265) && (De_vcnt < 12'd480);
wire time_border = time_panel &&
                  ((De_hcnt < 12'd155) || (De_hcnt >= 12'd1125) ||
                   (De_vcnt < 12'd270) || (De_vcnt >= 12'd475));

wire grid_dot = ((De_hcnt[6:0] < 7'd3) && (De_vcnt[6:0] < 7'd3));
wire left_bar = (De_hcnt >= 12'd128) && (De_hcnt < 12'd140) &&
                (De_vcnt >= 12'd200) && (De_vcnt < 12'd485);
wire right_bar = (De_hcnt >= 12'd1140) && (De_hcnt < 12'd1152) &&
                 (De_vcnt >= 12'd200) && (De_vcnt < 12'd485);

// Internal color format is {B,G,R}.
localparam [23:0] C_BG       = {8'h24,8'h10,8'h07};
localparam [23:0] C_BG_DOT   = {8'h36,8'h1E,8'h0F};
localparam [23:0] C_PANEL    = {8'h3E,8'h22,8'h0E};
localparam [23:0] C_PANEL2   = {8'h50,8'h2C,8'h16};
localparam [23:0] C_CYAN     = {8'hFF,8'hDC,8'h24};
localparam [23:0] C_GREEN    = {8'h88,8'hEF,8'h5E};
localparam [23:0] C_YELLOW   = {8'h40,8'hD2,8'hFF};
localparam [23:0] C_PINK     = {8'hA8,8'h70,8'hFF};
localparam [23:0] C_WHITE    = {8'hFA,8'hFA,8'hFA};
localparam [23:0] C_MUTED    = {8'hB4,8'h88,8'h68};

reg [23:0] Data_tmp;
always @(posedge I_pxl_clk or negedge I_rst_n) begin
    if (!I_rst_n)
        Data_tmp <= C_BG;
    else if (Pout_de_dn[2]) begin
        if (top_cyan)
            Data_tmp <= C_CYAN;
        else if (top_green)
            Data_tmp <= C_GREEN;
        else if (top_yellow)
            Data_tmp <= C_YELLOW;
        else if (top_pink)
            Data_tmp <= C_PINK;
        else if (title_pixel)
            Data_tmp <= C_WHITE;
        else if (main_border)
            Data_tmp <= C_CYAN;
        else if (left_bar)
            Data_tmp <= C_GREEN;
        else if (right_bar)
            Data_tmp <= C_PINK;
        else if (time_border)
            Data_tmp <= C_MUTED;
        else if (colon_pixel)
            Data_tmp <= C_WHITE;
        else if (digit_pixel && (De_hcnt < X_MT))
            Data_tmp <= C_CYAN;       // hours
        else if (digit_pixel && (De_hcnt < X_ST))
            Data_tmp <= C_GREEN;      // minutes
        else if (digit_pixel)
            Data_tmp <= C_YELLOW;     // seconds
        else if (time_panel)
            Data_tmp <= C_PANEL2;
        else if (main_panel)
            Data_tmp <= C_PANEL;
        else if (footer_pixel)
            Data_tmp <= C_WHITE;
        else if (grid_dot)
            Data_tmp <= C_BG_DOT;
        else
            Data_tmp <= C_BG;
    end else
        Data_tmp <= 24'h000000;
end

assign O_data_r = Data_tmp[7:0];
assign O_data_g = Data_tmp[15:8];
assign O_data_b = Data_tmp[23:16];

endmodule
