module video_top (
    input             I_clk,       // 27 MHz onboard clock
    input             I_key,       // S1, pin 87: +1 hour
    input             I_key2,      // S2, pin 88: +1 minute (seconds -> 00)
    output     [4:0]  O_led,
    output            O_tmds_clk_p,
    output            O_tmds_clk_n,
    output     [2:0]  O_tmds_data_p,
    output     [2:0]  O_tmds_data_n
);

wire pll_lock;
wire hdmi_rst_n;
wire clock_rst_n;
reg [19:0] por_cnt = 20'd0;

always @(posedge I_clk) begin
    if (por_cnt < 20'd1_000_000)
        por_cnt <= por_cnt + 1'b1;
end

assign clock_rst_n = (por_cnt >= 20'd1_000_000);

wire serial_clk;
wire pix_clk;

TMDS_rPLL u_tmds_rpll (
    .clkin  (I_clk),
    .clkout (serial_clk),
    .lock   (pll_lock)
);

assign hdmi_rst_n = pll_lock & clock_rst_n;

CLKDIV u_clkdiv (
    .RESETN (hdmi_rst_n),
    .HCLKIN (serial_clk),
    .CLKOUT (pix_clk),
    .CALIB  (1'b1)
);
defparam u_clkdiv.DIV_MODE = "5";
defparam u_clkdiv.GSREN    = "false";

wire [3:0] hour_tens;
wire [3:0] hour_ones;
wire [3:0] min_tens;
wire [3:0] min_ones;
wire [3:0] sec_tens;
wire [3:0] sec_ones;
wire blink;

// This is a wall clock, not a stopwatch. Set the displayed time with S1/S2.
// INIT_* is only the power-up fallback because the FPGA has no battery-backed RTC.
digital_clock #(
    .CLK_HZ      (27000000),
    .INIT_HOUR   (15),
    .INIT_MINUTE (41),
    .INIT_SECOND (0)
) u_clock (
    .clk        (I_clk),
    .rst_n      (clock_rst_n),
    .btn_hour   (I_key),
    .btn_minute (I_key2),
    .hour_tens  (hour_tens),
    .hour_ones  (hour_ones),
    .min_tens   (min_tens),
    .min_ones   (min_ones),
    .sec_tens   (sec_tens),
    .sec_ones   (sec_ones),
    .blink      (blink)
);

wire tp_vs, tp_hs, tp_de;
wire [7:0] tp_r, tp_g, tp_b;

clock_screen u_screen (
    .I_pxl_clk   (pix_clk),
    .I_rst_n     (hdmi_rst_n),
    .I_hour_tens (hour_tens),
    .I_hour_ones (hour_ones),
    .I_min_tens  (min_tens),
    .I_min_ones  (min_ones),
    .I_sec_tens  (sec_tens),
    .I_sec_ones  (sec_ones),
    .I_blink     (blink),
    .I_h_total   (12'd1650),
    .I_h_sync    (12'd40),
    .I_h_bporch  (12'd220),
    .I_h_res     (12'd1280),
    .I_v_total   (12'd750),
    .I_v_sync    (12'd5),
    .I_v_bporch  (12'd20),
    .I_v_res     (12'd720),
    .I_hs_pol    (1'b1),
    .I_vs_pol    (1'b1),
    .O_de        (tp_de),
    .O_hs        (tp_hs),
    .O_vs        (tp_vs),
    .O_data_r    (tp_r),
    .O_data_g    (tp_g),
    .O_data_b    (tp_b)
);

DVI_TX_Top u_dvi (
    .I_rst_n       (hdmi_rst_n),
    .I_serial_clk  (serial_clk),
    .I_rgb_clk     (pix_clk),
    .I_rgb_vs      (tp_vs),
    .I_rgb_hs      (tp_hs),
    .I_rgb_de      (tp_de),
    .I_rgb_r       (tp_r),
    .I_rgb_g       (tp_g),
    .I_rgb_b       (tp_b),
    .O_tmds_clk_p  (O_tmds_clk_p),
    .O_tmds_clk_n  (O_tmds_clk_n),
    .O_tmds_data_p (O_tmds_data_p),
    .O_tmds_data_n (O_tmds_data_n)
);

reg [24:0] hb = 25'd0;
always @(posedge I_clk)
    hb <= hb + 1'b1;

assign O_led[0] = ~hb[24];
assign O_led[1] = ~blink;
assign O_led[2] = 1'b1;
assign O_led[3] = 1'b1;
assign O_led[4] = 1'b1;

endmodule
