// 24-hour wall-clock core for Tang Nano 20K.
// Uses the 27 MHz onboard clock as the time base.
// S1 increments hour, S2 increments minute.
// After power loss the FPGA has no battery-backed RTC, so it restarts from INIT_*.
module digital_clock #(
    parameter integer CLK_HZ      = 27000000,
    parameter integer INIT_HOUR   = 15,
    parameter integer INIT_MINUTE = 41,
    parameter integer INIT_SECOND = 0
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       btn_hour,     // active-high S1
    input  wire       btn_minute,   // active-high S2
    output reg [3:0]  hour_tens,
    output reg [3:0]  hour_ones,
    output reg [3:0]  min_tens,
    output reg [3:0]  min_ones,
    output reg [3:0]  sec_tens,
    output reg [3:0]  sec_ones,
    output wire       blink
);

// -----------------------------------------------------------------------------
// 1-second divider
// -----------------------------------------------------------------------------
reg [24:0] sec_div;
assign blink = (sec_div < (CLK_HZ/2));

// -----------------------------------------------------------------------------
// Button synchronizers + debounce (~20 ms at 27 MHz)
// -----------------------------------------------------------------------------
localparam integer DB_COUNT = CLK_HZ / 50;

reg [1:0] hour_sync;
reg [1:0] min_sync;
reg       hour_state;
reg       min_state;
reg [19:0] hour_db_cnt;
reg [19:0] min_db_cnt;
reg       hour_press;
reg       min_press;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        hour_sync   <= 2'b00;
        min_sync    <= 2'b00;
        hour_state  <= 1'b0;
        min_state   <= 1'b0;
        hour_db_cnt <= 20'd0;
        min_db_cnt  <= 20'd0;
        hour_press  <= 1'b0;
        min_press   <= 1'b0;
    end else begin
        hour_sync <= {hour_sync[0], btn_hour};
        min_sync  <= {min_sync[0],  btn_minute};

        hour_press <= 1'b0;
        min_press  <= 1'b0;

        if (hour_sync[1] == hour_state) begin
            hour_db_cnt <= 20'd0;
        end else if (hour_db_cnt >= DB_COUNT-1) begin
            hour_db_cnt <= 20'd0;
            hour_state  <= hour_sync[1];
            if (hour_sync[1])
                hour_press <= 1'b1;
        end else begin
            hour_db_cnt <= hour_db_cnt + 1'b1;
        end

        if (min_sync[1] == min_state) begin
            min_db_cnt <= 20'd0;
        end else if (min_db_cnt >= DB_COUNT-1) begin
            min_db_cnt <= 20'd0;
            min_state  <= min_sync[1];
            if (min_sync[1])
                min_press <= 1'b1;
        end else begin
            min_db_cnt <= min_db_cnt + 1'b1;
        end
    end
end

// -----------------------------------------------------------------------------
// 24-hour time-of-day counter
// ----------------------------------------------------------------------------

// Helpers implemented inline as BCD rollover logic.
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sec_div   <= 25'd0;
        hour_tens <= INIT_HOUR / 10;
        hour_ones <= INIT_HOUR % 10;
        min_tens  <= INIT_MINUTE / 10;
        min_ones  <= INIT_MINUTE % 10;
        sec_tens  <= INIT_SECOND / 10;
        sec_ones  <= INIT_SECOND % 10;
    end else begin
        // Manual setting has priority over the automatic tick.
        if (hour_press) begin
            if ((hour_tens == 4'd2) && (hour_ones == 4'd3)) begin
                hour_tens <= 4'd0;
                hour_ones <= 4'd0;
            end else if (hour_ones == 4'd9) begin
                hour_ones <= 4'd0;
                hour_tens <= hour_tens + 1'b1;
            end else begin
                hour_ones <= hour_ones + 1'b1;
            end
        end

        if (min_press) begin
            if ((min_tens == 4'd5) && (min_ones == 4'd9)) begin
                min_tens <= 4'd0;
                min_ones <= 4'd0;
            end else if (min_ones == 4'd9) begin
                min_ones <= 4'd0;
                min_tens <= min_tens + 1'b1;
            end else begin
                min_ones <= min_ones + 1'b1;
            end
            // Make it easy to synchronize the clock to a real minute boundary.
            sec_tens <= 4'd0;
            sec_ones <= 4'd0;
            sec_div  <= 25'd0;
        end else if (sec_div >= CLK_HZ-1) begin
            sec_div <= 25'd0;

            if (sec_ones < 4'd9) begin
                sec_ones <= sec_ones + 1'b1;
            end else begin
                sec_ones <= 4'd0;
                if (sec_tens < 4'd5) begin
                    sec_tens <= sec_tens + 1'b1;
                end else begin
                    sec_tens <= 4'd0;
                    if (min_ones < 4'd9) begin
                        min_ones <= min_ones + 1'b1;
                    end else begin
                        min_ones <= 4'd0;
                        if (min_tens < 4'd5) begin
                            min_tens <= min_tens + 1'b1;
                        end else begin
                            min_tens <= 4'd0;
                            if ((hour_tens == 4'd2) && (hour_ones == 4'd3)) begin
                                hour_tens <= 4'd0;
                                hour_ones <= 4'd0;
                            end else if (hour_ones == 4'd9) begin
                                hour_ones <= 4'd0;
                                hour_tens <= hour_tens + 1'b1;
                            end else begin
                                hour_ones <= hour_ones + 1'b1;
                            end
                        end
                    end
                end
            end
        end else begin
            sec_div <= sec_div + 1'b1;
        end
    end
end

endmodule
